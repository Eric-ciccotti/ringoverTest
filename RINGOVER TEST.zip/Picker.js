class Picker {
    constructor(x, y) {
        //pas le temps de finir...
    }
}

export default Picker;